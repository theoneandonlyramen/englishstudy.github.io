> [!CAUTION]  
> This repository is outdated, as Z-Kit is no longer hosted statically.

<p align="center">
  <img src="https://github.com/user-attachments/assets/40df0ec0-7dc4-43f3-99cb-b87a2b7b163b" alt="Full Z-Kit Logo">
<p align="center">
<h1 align="center"><a href = "https://github.com/Z-Kit-Team/Z-Kit/blob/main/INSTANCES.md">Links + Deployment Info</a></h1>

<h2 align="center"> Z-Kit is a fully unblockable proxy suite.</h2>

> [!NOTE]  
> If you would like to host your own Z-Kit instance, check out [this link](https://github.com/Z-Kit-Team/Z-Kit/blob/main/INSTANCES.md)!

## Features
```
├── Clean UI
│   └── Tysm VRTZ
├── Games
│   ├── Roblox
│   └── 3kh0 Lite
├── Apps
│   ├── Now.GG
│   └── GeForce NOW
└── Proxy
    └── Ultraviolet
```

## Stargazers
Massive thanks to anyone who stars Z-Kit, you mean a lot to us. ♡

<a href="https://www.star-history.com/#Z-Kit-Team/Z-Kit&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=Z-Kit-Team/Z-Kit&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=Z-Kit-Team/Z-Kit&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=Z-Kit-Team/Z-Kit&type=Date" />
 </picture>
</a>

## Keywords (ignore)
securly, goguardian, cisco umbrella, relay, unblocker, proxy, unblocked games, bypass, school blocker, unblocked, chromebook
