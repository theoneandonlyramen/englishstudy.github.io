self.__uv$config = {
    prefix: '/z/-kit/',
    bare:'https://goto.zkit.above.gay/',
    encodeUrl: Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler: '/z/kit/uv.handler.js',
    bundle: '/z/kit/uv.bundle.js',
    config: '/z/kit/uv.config.js',
    sw: '/z/kit/uv.sw.js',
};
